﻿
// File Name: Transport.cs
// Created By: Padma Priya Duvvuri
// Created On: 22-Dec-2011

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ORS
{
    public enum  Stations
    {
        Amsterdam,
        Berlin,
        Copenhagen,
        Paris,
        Hanover,
        Rome,
        Munich,
        Madrid,
        Milan,
        Zurich,
        Napels,
        Frankfurt,
        Vienna,
        Helsinki,
        Kiruna,
        Stockholm
    }
}
